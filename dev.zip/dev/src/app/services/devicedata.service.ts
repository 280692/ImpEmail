import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

declare var defaultOriginalImage_Host: String;

@Injectable()
export class DeviceDataService {
    constructor(private http:Http) { }
    getDeviceDataWithObservable(make: String, model: String): Observable<any> {
        return this.http.get("/ecareapi/v1/device/make/" + make+ "/model/" + model + ".json?appId=ecare")
	        .map(this.extractData)
	        .catch(this.handleErrorObservable);
    }

    private extractData(res: Response) {
      	let body = res.json();
        if(body.originalImageURL == null || body.originalImageURL.length < 1){
            if(body.deviceTypeGroupName == 'Phone'){
              body.originalImageURL = defaultOriginalImage_Host + '/ecms/dam/att/consumer/help/image/ico-no-device-phone-200x300-gray.png';
            }
            else if(body.deviceTypeGroupName == 'Tablet') {
              body.originalImageURL = defaultOriginalImage_Host + '/ecms/dam/att/consumer/help/image/ico-no-device-tablet-200x300-gray.png';
            }
            else if(body.deviceTypeGroupName == 'Wearable') {
              body.originalImageURL = defaultOriginalImage_Host + '/ecms/dam/att/consumer/help/image/ico-no-device-wearable-200x300-gray.png';
            }
            else{
              body.originalImageURL = defaultOriginalImage_Host + '/ecms/dam/att/consumer/help/image/ico-no-device-datacard-200x300-gray.png';
              }
        }
        return body;
    }
    private handleErrorObservable (error: Response | any) {
    	console.error(error.message || error);
    	return Observable.throw(error.message || error);
    }

}
