import { Component, OnInit, Input} from "@angular/core";
import { Observable } from 'rxjs';
declare var $: any;
@Component({
    selector: "polularsolutions",
    templateUrl: './polularsolutions.html'

})
export class PolularSolutionsComponent implements OnInit{
@Input() topSolutionsData: any;
@Input() viewAllSolLink: String;
topSolutions: string [] = [] ;
  ngOnInit(): void {
    for (let entry of $(this.topSolutionsData.resultBody.contentTypeProperties.topsoln).find('a')) {
          if(entry.innerHTML.length > 31){
                entry.innerHTML = entry.innerHTML.substr(0, 29) + "\u2026";
          }
          this.topSolutions.push(entry.outerHTML);
      }
  }
}
