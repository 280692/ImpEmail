import { Component, Input} from "@angular/core";
@Component({
    selector: "deviceinfo",
    templateUrl: './deviceinfo.html'

})
export class DeviceInfoComponent{
        @Input() deviceData: any;
        async ngAfterViewInit() {
          await this.loadScript("/global-search/static/widget/js/searchWidgetScript.js")
        }
        private loadScript(scriptUrl: string) {
          return new Promise((resolve, reject) => {
            const scriptElement = document.createElement('script')
            scriptElement.src = scriptUrl
            scriptElement.onload = resolve
            document.body.appendChild(scriptElement)
          })
        }
}
