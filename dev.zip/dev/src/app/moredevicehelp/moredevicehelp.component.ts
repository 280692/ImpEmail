import { Component,OnInit, Input } from "@angular/core";
declare var $: any;
declare var deviceUpgradeTime_Days: any;
@Component({
    selector: "moredevicehelp",
    templateUrl: './moredevicehelp.html'

})
export class MoreDeviceHelpComponent implements OnInit {
        @Input() deviceData: any;
        @Input() viewAllSolLink: String;
        isMyAttLinkValue : boolean = false;
        isUpgradeLinkValue : boolean;
        ngOnInit(): void {
          var linkCount = 1;
          if(this.deviceData.troubleshooting == 'true'){
              linkCount = linkCount + 1;
          }
          if(this.deviceData.softwareUpdatesLink != null){
              linkCount = linkCount + 1;
          }
          if(this.deviceData.desktopDeviceDiagramImageUrl != null){
            linkCount = linkCount + 1;
          }
          if(this.deviceData.userManualLink != null != null){
            linkCount = linkCount + 1;
          }
          if(linkCount < 6) {
            this.isMyAttLinkValue = true;
            linkCount = linkCount + 1;
          }
          if(linkCount < 6 && this.deviceData.deviceLaunchDate != null && Math.floor((new Date().getTime() - new Date(this.deviceData.deviceLaunchDate).getTime())/(1000*60*60*24)) > deviceUpgradeTime_Days) {
            this.isUpgradeLinkValue = true;
          }
          $(window).load();
        }
    }
