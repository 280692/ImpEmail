import { Component, Input } from "@angular/core";
@Component({
    selector: "breadcrumb",
    templateUrl: './breadcrumb.html'

})
export class BreadcrumbComponent {
        @Input() deviceData: any;
    }
