import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { HttpModule } from '@angular/http';
import { AppComponent } from "./app.component";
import { BreadcrumbComponent } from "./breadcrumb/breadcrumb.component";
import { DeviceInfoComponent } from "./deviceinfo/deviceinfo.component";
import { MoreDeviceHelpComponent } from "./moredevicehelp/moredevicehelp.component";
import { PolularSolutionsComponent } from "./popularsolutions/polularsolutions.component";
import { DeviceDataService } from './services/devicedata.service';
import { TopSolutionService } from './services/topsolutions.service';
import { TopicTreeService } from './services/topictree.service';
@NgModule({
    imports: [
        BrowserModule,HttpModule

    ],
    declarations: [
        AppComponent,BreadcrumbComponent,DeviceInfoComponent,MoreDeviceHelpComponent,PolularSolutionsComponent
    ],
    providers: [
          DeviceDataService, TopSolutionService, TopicTreeService
  	],
    bootstrap: [
        AppComponent
    ]
})
export class AppModule {}
