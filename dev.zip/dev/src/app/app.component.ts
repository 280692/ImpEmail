import { Component, OnInit } from '@angular/core';
import {Title} from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { DeviceDataService } from './services/devicedata.service';
import { TopSolutionService } from './services/topsolutions.service';
import { TopicTreeService } from './services/topictree.service';

@Component({
    selector: "device-landing",
    templateUrl: './app.component.html',
    styleUrls: [
        './css/device-support-desktop.css'
    ]
})
  export class AppComponent implements OnInit{
         observableDeviceData: Observable<any>;
         deviceData: any;
         observableTopSolutionsData: Observable<any>;
         topSolutionsData: any;
         observableTopicTreeData: Observable<any>;
         topicTreeData: any;
         errorMessage: String;
         viewAllSolLink: String;
         constructor(private titleService: Title, private deviceDataService: DeviceDataService, private topSolutionService: TopSolutionService, private topicTreeService: TopicTreeService) { }
         ngOnInit(): void {
              let wirelessDeviceCookie = this.getCookie('wirelessDevice');
              console.log('Cookie' + wirelessDeviceCookie);
              if(!(wirelessDeviceCookie && wirelessDeviceCookie != null && wirelessDeviceCookie.length > 0)){
                    wirelessDeviceCookie = 'att|Apple|iPhone7';
              }
              let cookieArr: Array<string> = wirelessDeviceCookie.split('\|');
              this.observableDeviceData = this.deviceDataService.getDeviceDataWithObservable(cookieArr[1], cookieArr[2]);
              this.observableDeviceData.subscribe(
                  deviceData => {this.deviceData = deviceData;
                  this.titleService.setTitle(this.deviceData.displayName + ' Support & How-To Guides - AT&T');
                  },
                  error =>  this.errorMessage = <any>error);
              this.observableTopSolutionsData = this.topSolutionService.getTopSolutionsDataWithObservable(cookieArr[1], cookieArr[2]);
              this.observableTopSolutionsData.subscribe(
                  data => this.topSolutionsData = data,
                  error =>  this.errorMessage = <any>error);
              this.observableTopicTreeData = this.topicTreeService.getTopicTreeDataWithObservable(cookieArr[1], cookieArr[2]);
              this.observableTopicTreeData.subscribe(
                  data => {this.topicTreeData = data;
                  this.viewAllSolLink = '/devicehowto/index.html#!/tutorials/topic/'+ this.topicTreeData.solrTopic[0].children[0].id + '?make='+ this.deviceData.manufacturerMake + '&model='+ this.deviceData.model;
                  },
                  error =>  this.errorMessage = <any>error);
         }

         private getCookie(cname: string) {
            let name = cname + "=";
            let ca: Array<string>  = document.cookie.split(';');
            for(let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
       }

    }
